

import React, { Fragment } from 'react'


interface ExperienceCardProps {
        startYear: number
        endYear: number
        title: string
        subTitle: string
        description: string,
        onDelete: () => void
        onEdit: () => void
}
const ExperienceCard: React.FC<ExperienceCardProps> = ({ startYear, endYear, title, subTitle, description,onDelete,onEdit }) => {
        return (
               <Fragment>
                 <div className=' w-full my-8 border-b border-gray-300 pb-4'>
                        <div className='flex  justify-between'>
                                <div><p className='p-2 bg-orange-100 rounded-4xl'>{startYear}-{endYear}</p></div>
                                <div className='flex  flex-row-reverse gap-3 w-fit'>
                                        <div className=" p-2 bg-red-400 w-fit  rounded h-fit me-3 md:me-0 cursor-pointer" onClick={() => { 
                                            
                                                 onDelete();
                                        }}>
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="white" className="size-3">
                                                        <path strokeLinecap="round" strokeLinejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0" />
                                                </svg>
                                        </div>

                                        <div className=" p-2 bg-red-100 w-fit  rounded h-fit me-3 md:me-0 cursor-pointer" onClick={()=>onEdit()}>
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="size-3">
                                                        <path strokeLinecap="round" strokeLinejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L6.832 19.82a4.5 4.5 0 0 1-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 0 1 1.13-1.897L16.863 4.487Zm0 0L19.5 7.125" />
                                                </svg>

                                        </div>
                                </div>
                        </div>

                        {/*  */}
                        <p className='font-bold text-xl pb-3 pt-3'>{title}</p>
                        <p className='font-semibold text-lg pb-3 text-green-600'>{subTitle}</p>

                        <p className='text-sm text-gray-500'>{description}</p>


                </div>

                
               </Fragment>
        )
}
export default ExperienceCard;